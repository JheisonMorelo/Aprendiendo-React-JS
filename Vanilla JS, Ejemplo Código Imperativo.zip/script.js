// Vanilla JavaScript

// Primero, recuperamos el botón
//const button = document.querySelector('button');

// Ahora recuperamos todos los botones
const buttons = document.querySelectorAll('button');

// Al hacer click en el botón, tenemos que escuchar una función
// button.addEventListener('click', function() {
//   // Recuperar la id del atributo del HTML
//   const id = button.getAttribute('data-id');

//   // Llamar a un servicio para actualizar si me gusta
//   // toggleLike(id)

//   if(button.classList.contains('liked')) {
//     button.classList.remove('liked');
//     button.innerText = 'Me gusta';
//   } else {
//     button.classList.add('liked');
//     button.innerText = 'Quitar me gusta';
//   }
// })

buttons.forEach(button => {
  button.addEventListener('click', function () {
    // Recuperar la id del atributo del HTML
    const id = button.getAttribute('data-id');
    // Llamar a un servicio para actualizar si me gusta
    // toggleLike(id)

    if (button.classList.contains('liked')) {
      button.classList.remove('liked');
      button.innerText = 'Me gusta';
    } else {
      button.classList.add('liked');
      button.innerText = 'Quitar me gusta';
    }
  })
})

// CÓDIGO IMPERATIVO:
// Decir en el código CÓMO TIENEN QUE HACER LAS COSAS